setwd("C:\\Users\\it24102680\\Desktop\\IT24102680_lab5")

Delivery_Times <-read.table("Exercise - Lab 05.txt", header=TRUE, sep = ",")
fix(Delivery_Times)

names(Delivery_Times) <-("Minutes")
attach(Delivery_Times)

histogram<-hist(Minutes, main ="Histogram fror Delivery times", breaks = seq(20,70, length.out=10) ,right = FALSE)

breaks <-round(histogram$breaks)
freq <-histogram$counts
mids <-  histogram$mids

cum.freq <- cumsum(freq)

new<-c()

for(i in 1:length(breaks)){
  if(i==1){
    new[i]=0
  }else{
    new[i]=cum.freq[i-1]
  }
}

plot(breaks, new, type ='l',main = "Cumulative Frequecy Polygon for Deliver Times",
     xlab="Deliver Times",ylab = "Cumulative Frequency",ylim=c(0,max(cum.freq)))
cbind(Upper=breaks,CumFreq = new)