setwd("C:\\Users\\ransi\\Desktop\\IT24102680_lab9")

# Set seed for reproducibility
set.seed(123)

# Part (i) Generate random sample
baking_times <- rnorm(n = 25, mean = 45, sd = 2)
print(baking_times)

# Part (ii) Hypothesis test
# H0: mean = 46
# H1: mean < 46

t_test_result <- t.test(baking_times, mu = 46, alternative = "less")
print(t_test_result)


