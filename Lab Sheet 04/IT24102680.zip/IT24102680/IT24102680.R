setwd("C:\\Users\\it24102680\\Desktop\\IT24102680")

#question 01
branch_data <-read.table("Exercise.txt", header=TRUE, sep = ",")
fix(branch_data)

#question 02
head(branch_data)
sapply (branch_data, class)

#question 03
boxplot(branch_data$Sales_X1,main="Box plot for sales",outline=TRUE,outpch=8,horizontal=TRUE)

#question 04
print(fivenum(branch_data$Advertising_X2))
IQR(branch_data$Advertising_X2)

#question 05
get.outliers <- function(z){
  q1 <- quantile(z)[2]
  q3 <- quantile(z)[4]
  iqr <- q3-q1
  
  ub <- q3 + 1.5*iqr
  lb <- q1 - 1.5*iqr
  
  print(paste("Outliers:",paste(sort(z[z<lb | z>ub]),collapse = ",")))
}
get.outliers(branch_data$Years_X3)
